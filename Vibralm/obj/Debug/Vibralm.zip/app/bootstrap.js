//The bootstrap.js file is the last searched in the load chain after package.json and index.js.
// This one exists here temporarily because of a glitch in the NativeScript companion App for ios,
// which requires bootstrap.js file to exist.
require("./");
